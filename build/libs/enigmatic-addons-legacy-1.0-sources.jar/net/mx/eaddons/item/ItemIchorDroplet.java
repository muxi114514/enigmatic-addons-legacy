package net.mx.eaddons.item;

import keletu.enigmaticlegacy.EnigmaticLegacy;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemIchorDroplet extends Item {
    public static final ItemIchorDroplet INSTANCE = new ItemIchorDroplet();

    public ItemIchorDroplet() {
        func_77656_e(0);
        field_77777_bU = 64;
        func_77655_b("ichor_droplet");
        setRegistryName("ichor_droplet");
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.UNCOMMON;
    }
}
