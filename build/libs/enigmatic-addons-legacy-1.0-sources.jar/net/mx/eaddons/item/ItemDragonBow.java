package net.mx.eaddons.item;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import keletu.enigmaticlegacy.EnigmaticLegacy;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class ItemDragonBow extends ItemBow {
    public static final ItemDragonBow INSTANCE = new ItemDragonBow();

    public ItemDragonBow() {
        super();
        func_77656_e(1024);
        func_77655_b("dragon_bow");
        setRegistryName("dragon_bow");
        func_77625_d(1);
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    public static float getPowerForTime(int tick) {
        float f = (float) tick / 32.0F;
        f = (f * f + f * 2.0F) / 3.0F;
        return Math.min(f, 1.0F);
    }

    public static void resetEffect(ItemStack stack) {
        NBTTagCompound tag = stack.func_77978_p();
        if (tag != null) {
            tag.func_82580_o("CustomPotionEffects");
        }
    }

    public static void addEffect(ItemStack stack, PotionEffect effect) {
        if (!stack.func_77942_o()) {
            stack.func_77982_d(new NBTTagCompound());
        }
        @SuppressWarnings("null")
        NBTTagCompound tag = stack.func_77978_p();
        List<PotionEffect> effects = getCustomEffects(tag);
        int max = DragonBowConfig.maxPotionAmount;

        if (effects.size() < max) {
            effects.add(effect);
        } else {
            List<PotionEffect> newEffects = new ArrayList<>();
            for (int i = 1; i < effects.size(); i++) {
                newEffects.add(effects.get(i));
            }
            newEffects.add(effect);
            effects = newEffects;
        }

        if (!effects.isEmpty()) {
            NBTTagList list = new NBTTagList();
            for (PotionEffect e : effects) {
                list.func_74742_a(e.func_82719_a(new NBTTagCompound()));
            }
            tag.func_74782_a("CustomPotionEffects", list);
        }
    }

    public static List<PotionEffect> getCustomEffects(NBTTagCompound tag) {
        List<PotionEffect> effects = new ArrayList<>();
        if (tag != null && tag.func_150297_b("CustomPotionEffects", 9)) {
            NBTTagList list = tag.func_150295_c("CustomPotionEffects", 10);
            for (int i = 0; i < list.func_74745_c(); i++) {
                PotionEffect effect = PotionEffect.func_82722_b(list.func_150305_b(i));
                if (effect != null) {
                    effects.add(effect);
                }
            }
        }
        return effects;
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC;
    }

    @Override
    public void func_77615_a(ItemStack stack, World world, EntityLivingBase user, int timeLeft) {
        if (!(user instanceof EntityPlayer)) return;
        EntityPlayer player = (EntityPlayer) user;

        int charge = this.func_77626_a(stack) - timeLeft;
        float power = getPowerForTime(charge);
        if (power < 0.1F) return;

        stack.func_77972_a(1, player);

        if (!world.field_72995_K) {
            List<PotionEffect> effects = getCustomEffects(stack.func_77978_p());
            int powerLevel = EnchantmentHelper.func_77506_a(Enchantments.field_185309_u, stack);
            int punch = EnchantmentHelper.func_77506_a(Enchantments.field_185310_v, stack);
            int multi = EnchantmentHelper.func_77506_a(EnchantmentMultishot.INSTANCE, stack) > 0 ? 1 : 0;

            for (int index = -multi; index < 1 + multi; index++) {
                EntityDragonBreathArrow arrow = new EntityDragonBreathArrow(world, player);
                arrow.func_184547_a(player, player.field_70125_A, player.field_70177_z, 0.0F, power * 3.6F, 1.0F);
                arrow.field_70159_w *= 0.95D;
                arrow.field_70181_x = arrow.field_70181_x * 0.95D + 0.135D * index;
                arrow.field_70179_y *= 0.95D;

                if (!effects.isEmpty()) {
                    for (PotionEffect effect : effects) {
                        arrow.addEffect(effect);
                    }
                }

                if (powerLevel > 0) {
                    arrow.func_70239_b(arrow.func_70242_d() + powerLevel * 0.8);
                }
                if (punch > 0) {
                    arrow.func_70240_a(punch);
                }

                world.func_72838_d(arrow);
            }
        }

        world.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v,
                SoundEvents.field_187737_v, SoundCategory.PLAYERS,
                1.0F, 2.5F / (field_77697_d.nextFloat() * 0.4F + 1.2F) + power * 0.5F);

        player.func_71029_a(StatList.func_188057_b(this));
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);
        player.func_184598_c(hand);
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        List<PotionEffect> effects = getCustomEffects(stack.func_77978_p());
        if (effects.isEmpty()) {
            tooltip.add(TextFormatting.DARK_PURPLE + "You can combine this with potions.");
        } else {
            for (PotionEffect effect : effects) {
                tooltip.add(TextFormatting.BLUE + effect.func_76453_d());
            }
        }
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        if (enchantment == Enchantments.field_185312_x || enchantment == Enchantments.field_185311_w) {
            return false;
        }
        if (enchantment == EnchantmentMultishot.INSTANCE) {
            return true;
        }
        return super.canApplyAtEnchantingTable(stack, enchantment);
    }

    @Override
    public int func_77619_b() {
        return 1;
    }
}
