package net.mx.eaddons.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mx.eaddons.EAddonsMod;
import keletu.enigmaticlegacy.EnigmaticLegacy;

import javax.annotation.Nullable;
import java.util.*;

public class ItemArtificialFlower extends Item {
    public static final ItemArtificialFlower INSTANCE = new ItemArtificialFlower();

    public ItemArtificialFlower() {
        func_77656_e(0);
        field_77777_bU = 1;
        func_77655_b("artificial_flower");
        setRegistryName("artificial_flower");
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public boolean func_77636_d(ItemStack stack) {
        NBTTagCompound tag = stack.func_77978_p();
        return tag != null && tag.func_74767_n("FlowerEnable");
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);
        NBTTagCompound tag = stack.func_77978_p();
        if (tag == null) {
            tag = new NBTTagCompound();
            stack.func_77982_d(tag);
        }
        tag.func_74757_a("FlowerEnable", false);
        player.func_184811_cZ().func_185145_a(this, 30);
        if (!world.field_72995_K) {
            player.openGui(EAddonsMod.instance, AntiqueBagGuiHandler.FLOWER_GUI_ID, world,
                    (int) player.field_70165_t, (int) player.field_70163_u, (int) player.field_70161_v);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<String> list, ITooltipFlag flagIn) {
        list.add("");
        if (GuiScreen.func_146272_n()) {
            list.add(TextFormatting.GOLD + I18n.func_135052_a("tooltip.eaddons.artificial_flower.attribute_header"));
            int attrCount = 0;
            for (int id = 1; id <= 3; id++) {
                Helper.AttributeData data = Helper.getAttribute(stack, id);
                if (data != null) {
                    list.add(GuiArtificialFlower.getAttributeText(data));
                    attrCount++;
                }
            }
            if (attrCount == 0) {
                list.add(TextFormatting.GRAY + I18n.func_135052_a("tooltip.eaddons.artificial_flower.none"));
            }

            list.add(TextFormatting.GOLD + I18n.func_135052_a("tooltip.eaddons.artificial_flower.effect_header"));
            int effectCount = 0;
            NBTTagCompound tag = stack.func_77978_p();
            boolean hasRing = tag != null && tag.func_74764_b("MagicRing");
            for (int id = 0; id < 2; id++) {
                Potion effect = Helper.getEffect(stack, id);
                if (effect == null)
                    continue;
                effectCount++;
                String name = I18n.func_135052_a(effect.func_76393_a());
                TextFormatting color = effect.func_188408_i() ? TextFormatting.GREEN : TextFormatting.RED;
                if (id == 0) {
                    String level = hasRing ? " II" : " I";
                    list.add(color + I18n.func_135052_a("tooltip.eaddons.artificial_flower.providing", name + level));
                } else {
                    list.add(color + I18n.func_135052_a("tooltip.eaddons.artificial_flower.immunity", name));
                }
            }
            if (effectCount == 0) {
                list.add(TextFormatting.GRAY + I18n.func_135052_a("tooltip.eaddons.artificial_flower.none"));
            }
        } else {
            list.add(I18n.func_135052_a("tooltip.eaddons.artificial_flower.hold_shift"));
        }
        list.add("");
    }

    @Override
    public void func_77663_a(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!(entity instanceof EntityPlayer))
            return;
        EntityPlayer player = (EntityPlayer) entity;
        NBTTagCompound tag = stack.func_77978_p();
        if (tag == null)
            return;

        if (player instanceof EntityPlayerMP) {
            UUID flowerEnableUUID = Helper.getPlayerEnableUUID(player);
            UUID flowerUUID = Helper.getFlowerUUID(stack);
            if ((flowerUUID == null || !flowerUUID.equals(flowerEnableUUID)) && tag.func_74767_n("FlowerEnable")) {
                tag.func_74757_a("FlowerEnable", false);
                for (int i = 1; i <= 3; i++) {
                    Helper.AttributeData data = Helper.getAttribute(stack, i);
                    if (data != null) {
                        IAttributeInstance inst = player.func_110140_aT()
                                .func_111152_a(data.attributeName);
                        if (inst != null) {
                            inst.func_111124_b(data.modifier);
                        }
                    }
                }
            }
        }

        boolean bagFlag = false;
        if (tag.func_74764_b("FlowerBagEnable")) {
            int bagSlot = tag.func_74762_e("FlowerBagEnable");
            if (ItemAntiqueBag.hasBag(player)) {
                List<ItemStack> inv = ItemAntiqueBag.getInventory(player);
                if (bagSlot >= 0 && bagSlot < inv.size()) {
                    ItemStack bagStack = inv.get(bagSlot);
                    UUID bagUUID = Helper.getFlowerUUID(bagStack);
                    UUID thisUUID = Helper.getFlowerUUID(stack);
                    bagFlag = bagUUID != null && bagUUID.equals(thisUUID);
                }
            }
        }

        if (!tag.func_74767_n("FlowerEnable") && !bagFlag)
            return;

        if (Helper.attributePool == null) {
            Helper.initRandomPool(player);
        }

        for (int i = 1; i <= 3; i++) {
            Helper.AttributeData data = Helper.getAttribute(stack, i);
            if (data != null && ArtificialFlowerConfig.isAttributeBlacklisted(data.attributeName)) {
                Helper.removeAttribute(stack, i);
            }
        }
        for (int i = 0; i < 2; i++) {
            Potion effect = Helper.getEffect(stack, i);
            if (effect != null) {
                ResourceLocation effectId = effect.getRegistryName();
                if (effectId != null && ArtificialFlowerConfig.isEffectBlacklisted(effectId)) {
                    Helper.removeEffect(stack, i);
                }
            }
        }

        Multimap<String, AttributeModifier> attrMap = HashMultimap.create();
        for (int i = 1; i <= 3; i++) {
            Helper.AttributeData data = Helper.getAttribute(stack, i);
            if (data != null) {
                attrMap.put(data.attributeName, data.modifier);
            }
        }
        if (player instanceof EntityPlayerMP && !attrMap.isEmpty()) {
            EntityPlayerMP serverPlayer = (EntityPlayerMP) player;
            Map<Multimap<String, AttributeModifier>, Integer> tickMap = ArtificialFlowerEventHandler.PLAYER_ATTRIBUTE_MAP
                    .computeIfAbsent(serverPlayer, k -> new HashMap<>());
            if (tickMap.containsKey(attrMap)) {
                tickMap.put(attrMap, 3);
            } else {
                tickMap.put(attrMap, 3);
            }
        }

        Potion effectImmuneTo = Helper.getEffect(stack, 1);
        if (effectImmuneTo != null && player.func_70644_a(effectImmuneTo)) {
            player.func_184589_d(effectImmuneTo);
        }

        Potion effectProvided = Helper.getEffect(stack, 0);
        int amplifier = 0;
        if (tag.func_74764_b("MagicRing"))
            amplifier++;
        if (effectProvided != null) {
            if (effectProvided.func_76403_b()) {
                if (player.field_70173_aa % 100 == 0) {
                    double modifier = ArtificialFlowerConfig.randomInstantaneousEffectModifier / 100.0;
                    effectProvided.func_180793_a(player, player, player, amplifier, modifier);
                }
            } else {
                PotionEffect newInstance = new PotionEffect(effectProvided, 36, amplifier, true, true);
                if (player.func_70644_a(effectProvided)) {
                    PotionEffect existing = player.func_70660_b(effectProvided);
                    if (existing != null) {
                        if (existing.func_76458_c() == amplifier && existing.func_76459_b() <= 4) {
                            player.func_184589_d(effectProvided);
                            player.func_70690_d(newInstance);
                        } else if (existing.func_76458_c() < amplifier) {
                            player.func_184589_d(effectProvided);
                            player.func_70690_d(newInstance);
                        }
                    }
                } else {
                    player.func_70690_d(newInstance);
                }
            }
        }
    }

    public static class Helper {

        public static List<IAttribute> attributePool;
        public static List<Potion> potionEffectPool;
        public static List<Potion> allEffectPool;

        public static void initRandomPool(EntityPlayer player) {
            List<IAttribute> attrBuilder = new ArrayList<>();
            for (IAttributeInstance inst : player.func_110140_aT().func_111146_a()) {
                IAttribute attr = inst.func_111123_a();
                if (!ArtificialFlowerConfig.isAttributeBlacklisted(attr.func_111108_a())) {
                    attrBuilder.add(attr);
                }
            }
            attributePool = Collections.unmodifiableList(attrBuilder);

            Set<Potion> potionEffects = new LinkedHashSet<>();
            for (PotionType type : ForgeRegistries.POTION_TYPES.getValuesCollection()) {
                for (PotionEffect pe : type.func_185170_a()) {
                    potionEffects.add(pe.func_188419_a());
                }
            }

            List<Potion> potionBuilder = new ArrayList<>();
            for (Potion p : potionEffects) {
                ResourceLocation id = p.getRegistryName();
                if (id == null)
                    continue;
                if (ArtificialFlowerConfig.isEffectBlacklisted(id))
                    continue;
                if (id.toString().contains("flight") || id.toString().contains("fly"))
                    continue;
                potionBuilder.add(p);
            }
            potionEffectPool = Collections.unmodifiableList(potionBuilder);

            List<Potion> allBuilder = new ArrayList<>();
            for (Potion p : ForgeRegistries.POTIONS.getValuesCollection()) {
                ResourceLocation id = p.getRegistryName();
                if (id == null)
                    continue;
                if (ArtificialFlowerConfig.isEffectBlacklisted(id))
                    continue;
                if (id.toString().contains("flight") || id.toString().contains("fly"))
                    continue;
                allBuilder.add(p);
            }
            allEffectPool = Collections.unmodifiableList(allBuilder);
        }

        public static class AttributeData {
            public final String attributeName;
            public final AttributeModifier modifier;

            public AttributeData(String attributeName, AttributeModifier modifier) {
                this.attributeName = attributeName;
                this.modifier = modifier;
            }
        }

        public static void setAttribute(ItemStack stack, int index, IAttribute attribute, AttributeModifier modifier) {
            NBTTagCompound tag = getOrCreateTag(stack);
            tag.func_74778_a("AttributeId" + index, attribute.func_111108_a());
            tag.func_74782_a("AttributeModifier" + index, SharedMonsterAttributes.func_111262_a(modifier));
        }

        public static void removeAttribute(ItemStack stack, int index) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null)
                return;
            tag.func_82580_o("AttributeId" + index);
            tag.func_82580_o("AttributeModifier" + index);
        }

        public static void setEffect(ItemStack stack, int index, Potion effect) {
            NBTTagCompound tag = getOrCreateTag(stack);
            ResourceLocation id = effect.getRegistryName();
            if (id != null) {
                tag.func_74778_a("PotionEffect" + index, id.toString());
            }
        }

        public static void removeEffect(ItemStack stack, int index) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null)
                return;
            tag.func_82580_o("PotionEffect" + index);
        }

        @Nullable
        public static AttributeData getAttribute(ItemStack stack, int index) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null)
                return null;
            String idKey = "AttributeId" + index;
            String modKey = "AttributeModifier" + index;
            if (!tag.func_150297_b(idKey, 8) || !tag.func_150297_b(modKey, 10))
                return null;
            String attrName = tag.func_74779_i(idKey);
            AttributeModifier modifier = SharedMonsterAttributes
                    .func_111259_a(tag.func_74775_l(modKey));
            if (modifier == null) {
                removeAttribute(stack, index);
                return null;
            }
            return new AttributeData(attrName, modifier);
        }

        @Nullable
        public static Potion getEffect(ItemStack stack, int index) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null)
                return null;
            String key = "PotionEffect" + index;
            if (!tag.func_150297_b(key, 8))
                return null;
            Potion effect = Potion.func_180142_b(tag.func_74779_i(key));
            if (effect == null) {
                removeEffect(stack, index);
                return null;
            }
            return effect;
        }

        public static void randomAttribute(EntityPlayer player, ItemStack stack, int index, int costMode,
                boolean boost) {
            if (attributePool == null || attributePool.isEmpty()) {
                initRandomPool(player);
            }
            if (attributePool.isEmpty())
                return;

            Random rand = player.func_70681_au();
            IAttribute attribute = attributePool.get(rand.nextInt(attributePool.size()));
            double offset = (costMode == 0 ? 0 : costMode == 1 ? 0.3 : 0.6) - (boost ? 0 : 0.125);
            double gaussian = MathHelper.func_151237_a(rand.nextGaussian() + offset, -2.5, 2.5);
            double maxMod = ArtificialFlowerConfig.randomAttributeMaxModifier / 100.0;
            double value = 0.01 * (int) (gaussian / 2.5 * (maxMod * 100));

            AttributeData oldData = getAttribute(stack, index);
            if (oldData != null) {
                IAttributeInstance inst = player.func_110140_aT().func_111152_a(oldData.attributeName);
                if (inst != null) {
                    inst.func_111124_b(oldData.modifier);
                }
            }

            if (value == 0) {
                removeAttribute(stack, index);
            } else {
                AttributeModifier modifier = new AttributeModifier(
                        UUID.randomUUID(), "ArtificialFlower" + index, value, 1);
                setAttribute(stack, index, attribute, modifier);
            }
        }

        public static void randomEffect(EntityPlayer player, ItemStack stack, int index) {
            if (allEffectPool == null || potionEffectPool == null) {
                initRandomPool(player);
            }
            if (allEffectPool.isEmpty())
                return;

            NBTTagCompound tag = getOrCreateTag(stack);
            int count = tag.func_74764_b("AllEffectCount") ? tag.func_74762_e("AllEffectCount") : 1;
            Random rand = player.func_70681_au();
            Potion effect;
            Potion otherEffect = getEffect(stack, 1 - index);
            do {
                if (index == 1 || rand.nextInt((count + 1) / 2 + 1) == 0) {
                    effect = allEffectPool.get(rand.nextInt(allEffectPool.size()));
                    tag.func_74768_a("AllEffectCount", count + 1);
                } else {
                    if (potionEffectPool.isEmpty()) {
                        effect = allEffectPool.get(rand.nextInt(allEffectPool.size()));
                    } else {
                        effect = potionEffectPool.get(rand.nextInt(potionEffectPool.size()));
                    }
                }
            } while (effect == otherEffect);

            Potion oldEffect = getEffect(stack, index);
            if (oldEffect != null && player.func_70644_a(oldEffect)) {
                player.func_184589_d(oldEffect);
            }
            setEffect(stack, index, effect);
        }

        public static ItemStack getFlowerStack(EntityPlayer player, boolean copy) {
            ItemStack mainHand = player.func_184614_ca();
            ItemStack flower;
            if (mainHand.func_77973_b() instanceof ItemArtificialFlower) {
                flower = mainHand;
            } else {
                flower = player.func_184592_cb();
            }
            return copy ? flower.func_77946_l() : flower;
        }

        @Nullable
        public static UUID getFlowerUUID(ItemStack stack) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null || !tag.func_186855_b("FlowerUUID"))
                return null;
            return tag.func_186857_a("FlowerUUID");
        }

        @Nullable
        public static UUID getPlayerEnableUUID(EntityPlayer player) {
            NBTTagCompound data = player.getEntityData();
            if (!data.func_74764_b("PlayerPersisted"))
                return null;
            NBTTagCompound persisted = data.func_74775_l("PlayerPersisted");
            if (!persisted.func_186855_b("FlowerEnableUUID"))
                return null;
            return persisted.func_186857_a("FlowerEnableUUID");
        }

        public static void setPlayerEnableUUID(EntityPlayer player, UUID uuid) {
            NBTTagCompound data = player.getEntityData();
            NBTTagCompound persisted;
            if (data.func_74764_b("PlayerPersisted")) {
                persisted = data.func_74775_l("PlayerPersisted");
            } else {
                persisted = new NBTTagCompound();
                data.func_74782_a("PlayerPersisted", persisted);
            }
            persisted.func_186854_a("FlowerEnableUUID", uuid);
        }

        private static NBTTagCompound getOrCreateTag(ItemStack stack) {
            NBTTagCompound tag = stack.func_77978_p();
            if (tag == null) {
                tag = new NBTTagCompound();
                stack.func_77982_d(tag);
            }
            return tag;
        }
    }
}
