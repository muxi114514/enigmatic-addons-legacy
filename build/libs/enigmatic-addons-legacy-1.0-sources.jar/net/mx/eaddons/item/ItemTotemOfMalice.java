package net.mx.eaddons.item;

import baubles.api.BaubleType;
import baubles.api.BaublesApi;
import baubles.api.IBauble;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Optional;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import keletu.enigmaticlegacy.EnigmaticLegacy;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@Optional.Interface(iface = "baubles.api.IBauble", modid = "baubles")
public class ItemTotemOfMalice extends Item implements IBauble {
    public static final ItemTotemOfMalice INSTANCE = new ItemTotemOfMalice();
    private static final String TAG_DURABILITY = "TotemDurability";

    public ItemTotemOfMalice() {
        func_77656_e(64);
        field_77777_bU = 1;
        func_77655_b("totem_of_malice");
        setRegistryName("totem_of_malice");
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC;
    }

    @Override
    public int getMaxDamage(ItemStack stack) {
        // Read Unbreaking level directly from NBT to avoid infinite recursion:
        // EnchantmentHelper → AstralSorcery hook → getDamage() → getMaxDamage() → loop
        int unbreakingLevel = 0;
        if (stack.func_77948_v()) {
            net.minecraft.nbt.NBTTagList enchList = stack.func_77986_q();
            int unbreakingId = Enchantment.func_185258_b(Enchantments.field_185307_s);
            for (int i = 0; i < enchList.func_74745_c(); i++) {
                net.minecraft.nbt.NBTTagCompound tag = enchList.func_150305_b(i);
                if (tag.func_74765_d("id") == unbreakingId) {
                    unbreakingLevel = tag.func_74765_d("lvl");
                    break;
                }
            }
        }
        return TotemOfMaliceConfig.baseDurability + unbreakingLevel;
    }

    /** Remaining uses (stored in NBT). New items default to max. */
    public static int getRemainingUses(ItemStack stack) {
        if (stack.func_190926_b() || !(stack.func_77973_b() instanceof ItemTotemOfMalice))
            return 0;
        NBTTagCompound nbt = stack.func_179543_a("eaddons");
        if (nbt == null || !nbt.func_74764_b(TAG_DURABILITY)) {
            return INSTANCE.getMaxDamage(stack);
        }
        return nbt.func_74762_e(TAG_DURABILITY);
    }

    private static void setRemainingUses(ItemStack stack, int remaining) {
        int max = INSTANCE.getMaxDamage(stack);
        remaining = Math.max(0, Math.min(remaining, max));
        stack.func_190925_c("eaddons").func_74768_a(TAG_DURABILITY, remaining);
    }

    @Override
    public int getDamage(ItemStack stack) {
        return getMaxDamage(stack) - getRemainingUses(stack);
    }

    @Override
    public void setDamage(ItemStack stack, int damage) {
        int max = getMaxDamage(stack);
        int remaining = Math.max(0, max - damage);
        setRemainingUses(stack, remaining);
    }

    @Override
    public boolean func_77645_m() {
        return true;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        if (enchantment == Enchantments.field_185296_A)
            return false;
        return super.canApplyAtEnchantingTable(stack, enchantment);
    }

    @Override
    public int func_77619_b() {
        return 1;
    }

    @Override
    public boolean func_82789_a(ItemStack toRepair, ItemStack repair) {
        if (repair.func_190926_b())
            return false;
        String configId = TotemOfMaliceConfig.repairItemRegistryName;
        if (configId == null || configId.isEmpty())
            return false;
        ResourceLocation id;
        if (configId.indexOf(':') < 0) {
            id = new ResourceLocation("minecraft", configId);
        } else {
            String[] sp = configId.split(":", 2);
            id = new ResourceLocation(sp[0], sp[1]);
        }
        Item repairItem = ForgeRegistries.ITEMS.getValue(id);
        return repairItem != null && repair.func_77973_b() == repairItem;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public boolean func_77636_d(ItemStack stack) {
        return false;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<String> list, ITooltipFlag flagIn) {
        list.add("");
        if (GuiScreen.func_146272_n()) {
            list.add(TextFormatting.DARK_RED + I18n.func_135052_a("tooltip.eaddons.totem_of_malice.header"));
            list.add(I18n.func_135052_a("tooltip.eaddons.totem_of_malice.damage_illager",
                    TotemOfMaliceConfig.damageBonusPercent + "%"));
            list.add(I18n.func_135052_a("tooltip.eaddons.totem_of_malice.reduce_illager",
                    TotemOfMaliceConfig.damageReductionPercent + "%"));
            list.add(I18n.func_135052_a("tooltip.eaddons.totem_of_malice.cheat_death"));
            list.add(I18n.func_135052_a("tooltip.eaddons.totem_of_malice.durability", getRemainingUses(stack),
                    getMaxDamage(stack)));
        } else {
            list.add(I18n.func_135052_a("tooltip.eaddons.totem_of_malice.hold_shift"));
        }
        list.add("");
    }

    @Override
    @Optional.Method(modid = "baubles")
    public BaubleType getBaubleType(ItemStack itemstack) {
        return BaubleType.AMULET;
    }

    @Override
    @Optional.Method(modid = "baubles")
    public void onEquipped(ItemStack itemstack, EntityLivingBase entity) {
    }

    @Override
    @Optional.Method(modid = "baubles")
    public void onUnequipped(ItemStack itemstack, EntityLivingBase entity) {
    }

    /** Whether the player has the totem in main hand, off hand, or bauble slot. */
    public static boolean hasTotemOfMalice(EntityPlayer player) {
        if (player == null)
            return false;
        if (!player.func_184614_ca().func_190926_b() && player.func_184614_ca().func_77973_b() == INSTANCE)
            return true;
        if (!player.func_184592_cb().func_190926_b() && player.func_184592_cb().func_77973_b() == INSTANCE)
            return true;
        return BaublesApi.isBaubleEquipped(player, INSTANCE) != -1;
    }

    /**
     * Returns the totem stack (main hand, then off hand, then bauble). Empty if
     * none.
     */
    public static ItemStack getTotemStack(EntityPlayer player) {
        if (player == null)
            return ItemStack.field_190927_a;
        ItemStack main = player.func_184614_ca();
        if (!main.func_190926_b() && main.func_77973_b() == INSTANCE)
            return main;
        ItemStack off = player.func_184592_cb();
        if (!off.func_190926_b() && off.func_77973_b() == INSTANCE)
            return off;
        int slot = BaublesApi.isBaubleEquipped(player, INSTANCE);
        if (slot != -1) {
            ItemStack bauble = BaublesApi.getBaubles(player).func_70301_a(slot);
            if (!bauble.func_190926_b() && bauble.func_77973_b() == INSTANCE)
                return bauble;
        }
        return ItemStack.field_190927_a;
    }

    /** Count curse enchantments on the stack (each curse adds to death burst). */
    public static int getCurseCount(ItemStack stack) {
        int count = 0;
        Map<Enchantment, Integer> enchants = EnchantmentHelper.func_82781_a(stack);
        for (Map.Entry<Enchantment, Integer> e : enchants.entrySet()) {
            if (e.getKey().func_190936_d())
                count += e.getValue();
        }
        return count;
    }

    /**
     * Consume one use from the stack. Caller must ensure stack is the same
     * reference as in hand/slot.
     */
    public static void consumeOneUse(ItemStack stack) {
        int remaining = getRemainingUses(stack) - 1;
        setRemainingUses(stack, remaining);
        if (remaining <= 0) {
            stack.func_77964_b(INSTANCE.getMaxDamage(stack));
        }
    }

    public static void register(net.minecraftforge.event.RegistryEvent.Register<Item> event) {
        event.getRegistry().register(INSTANCE);
    }

    public static void registerModels(net.minecraftforge.client.event.ModelRegistryEvent event) {
        net.minecraftforge.client.model.ModelLoader.setCustomModelResourceLocation(INSTANCE, 0,
                new net.minecraft.client.renderer.block.model.ModelResourceLocation("eaddons:totem_of_malice",
                        "inventory"));
    }
}
