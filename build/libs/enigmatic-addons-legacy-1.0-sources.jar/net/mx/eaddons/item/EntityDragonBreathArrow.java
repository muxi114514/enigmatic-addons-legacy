package net.mx.eaddons.item;

import com.google.common.collect.Sets;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.mx.eaddons.potion.PotionDragonBreath;

import java.util.List;
import java.util.Set;

import net.minecraft.entity.projectile.EntityArrow.PickupStatus;

public class EntityDragonBreathArrow extends EntityArrow {
    private final Set<PotionEffect> effects = Sets.newHashSet();

    public EntityDragonBreathArrow(World world) {
        super(world);
        this.func_70239_b(this.func_70242_d() * 2);
        this.field_70251_a = PickupStatus.DISALLOWED;
    }

    public EntityDragonBreathArrow(World world, EntityLivingBase shooter) {
        super(world, shooter);
        this.func_70239_b(this.func_70242_d() * 2);
        this.field_70251_a = PickupStatus.DISALLOWED;
    }

    @Override
    public void func_70071_h_() {
        super.func_70071_h_();
        if (this.field_70170_p.field_72995_K) {
            Vec3d movement = new Vec3d(this.field_70159_w, this.field_70181_x, this.field_70179_y);
            double dx = movement.field_72450_a;
            double dy = movement.field_72448_b;
            double dz = movement.field_72449_c;
            double length = movement.func_72433_c() * 1.25D;
            for (int i = 0; i < (int) length; ++i) {
                this.field_70170_p.func_175688_a(EnumParticleTypes.DRAGON_BREATH,
                        this.field_70165_t + (this.field_70146_Z.nextDouble() - 0.5) * this.field_70130_N + dx * (double) i / length,
                        this.field_70163_u + this.field_70146_Z.nextDouble() * this.field_70131_O + dy * (double) i / length,
                        this.field_70161_v + (this.field_70146_Z.nextDouble() - 0.5) * this.field_70130_N + dz * (double) i / length,
                        -dx * 0.1, -dy * 0.1, -dz * 0.1);
            }
            if (!this.func_189652_ae()) {
                this.field_70181_x += 0.02;
            }
        } else if (this.field_70254_i) {
            summonAreaEffect();
        }
    }

    @Override
    protected void func_184549_a(RayTraceResult result) {
        super.func_184549_a(result);
        if (!this.field_70170_p.field_72995_K && result.field_72313_a == RayTraceResult.Type.ENTITY
                && result.field_72308_g != this.field_70250_c) {
            Vec3d motion = new Vec3d(this.field_70159_w, this.field_70181_x, this.field_70179_y);
            this.func_70107_b(this.field_70165_t + motion.field_72450_a * 0.5, this.field_70163_u + motion.field_72448_b * 0.5, this.field_70161_v + motion.field_72449_c * 0.5);
            summonAreaEffect();
        }
    }

    @Override
    protected void func_184548_a(EntityLivingBase living) {
        super.func_184548_a(living);
        living.field_70172_ad = 0;
    }

    private void summonAreaEffect() {
        Vec3d motion = new Vec3d(this.field_70159_w, this.field_70181_x, this.field_70179_y);
        float speed = (float) motion.func_72433_c();
        float dmg = MathHelper.func_76143_f(MathHelper.func_151237_a(Math.sqrt(speed) * this.func_70242_d(), 0.0, 2.147483647E9)) / 4.0F;

        List<EntityLivingBase> entities = this.field_70170_p.func_72872_a(
                EntityLivingBase.class, this.func_174813_aQ().func_72314_b(4.0, 2.0, 4.0));

        EntityAreaEffectCloud effectCloud = new EntityAreaEffectCloud(this.field_70170_p, this.field_70165_t, this.field_70163_u, this.field_70161_v);
        if (this.field_70250_c instanceof EntityLivingBase) {
            effectCloud.func_184481_a((EntityLivingBase) this.field_70250_c);
        }

        effectCloud.func_184491_a(EnumParticleTypes.DRAGON_BREATH);
        effectCloud.func_184483_a(1.5F);
        effectCloud.func_184486_b(100);
        effectCloud.func_184495_b(0.1F);
        effectCloud.func_184485_d(1);
        effectCloud.func_184496_a(new PotionEffect(PotionDragonBreath.INSTANCE, 1, MathHelper.func_76141_d(dmg)));

        if (!this.effects.isEmpty()) {
            for (PotionEffect effect : this.effects) {
                PotionEffect scaled = new PotionEffect(effect.func_188419_a(), effect.func_76459_b() / 5, effect.func_76458_c());
                effectCloud.func_184496_a(scaled);
            }
        }

        if (!entities.isEmpty()) {
            for (EntityLivingBase entity : entities) {
                if (this.func_70068_e(entity) < 12.0 && entity != this.field_70250_c) {
                    effectCloud.func_70107_b(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
                    break;
                }
            }
        }

        this.field_70170_p.func_72838_d(effectCloud);
        this.func_70106_y();
    }

    @Override
    protected ItemStack func_184550_j() {
        return ItemStack.field_190927_a;
    }

    public void addEffect(PotionEffect effect) {
        this.effects.add(effect);
    }

    @Override
    public void func_70014_b(NBTTagCompound compound) {
        super.func_70014_b(compound);
        if (!this.effects.isEmpty()) {
            NBTTagList list = new NBTTagList();
            for (PotionEffect effect : this.effects) {
                list.func_74742_a(effect.func_82719_a(new NBTTagCompound()));
            }
            compound.func_74782_a("CustomPotionEffects", list);
        }
    }

    @Override
    public void func_70037_a(NBTTagCompound compound) {
        super.func_70037_a(compound);
        if (compound.func_150297_b("CustomPotionEffects", 9)) {
            NBTTagList list = compound.func_150295_c("CustomPotionEffects", 10);
            for (int i = 0; i < list.func_74745_c(); i++) {
                PotionEffect effect = PotionEffect.func_82722_b(list.func_150305_b(i));
                if (effect != null) {
                    this.effects.add(effect);
                }
            }
        }
    }


    @Override
    public boolean func_70241_g() {
        return false;
    }
}
