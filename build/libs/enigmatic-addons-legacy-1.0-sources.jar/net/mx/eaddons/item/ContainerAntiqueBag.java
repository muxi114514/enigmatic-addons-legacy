package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerAntiqueBag extends Container {
    private final InventoryAntiqueBag bagInventory;
    private final EntityPlayer player;

    public ContainerAntiqueBag(EntityPlayer player) {
        this.player = player;
        this.bagInventory = new InventoryAntiqueBag(player);

        // Bag slots: 2 rows x 6 columns = 12 slots
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 6; col++) {
                this.func_75146_a(new SlotAntiqueBag(bagInventory, col + row * 6,
                        35 + col * 18, 24 + row * 18));
            }
        }

        // Player inventory slots (3 rows x 9 columns)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.func_75146_a(new Slot(player.field_71071_by, col + row * 9 + 9,
                        8 + col * 18, 84 + row * 18));
            }
        }

        // Hotbar slots (1 row x 9 columns)
        for (int col = 0; col < 9; col++) {
            if (col == player.field_71071_by.field_70461_c) {
                // Lock the currently selected slot if holding the bag
                this.func_75146_a(new Slot(player.field_71071_by, col, 8 + col * 18, 142) {
                    @Override
                    public boolean func_82869_a(EntityPlayer playerIn) {
                        return false;
                    }

                    @Override
                    public boolean func_75214_a(ItemStack stack) {
                        return false;
                    }

                    @Override
                    public int func_75219_a() {
                        return 0;
                    }
                });
            } else {
                this.func_75146_a(new Slot(player.field_71071_by, col, 8 + col * 18, 142));
            }
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return true;
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack resultStack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d()) {
            ItemStack slotStack = slot.func_75211_c();
            resultStack = slotStack.func_77946_l();

            int bagSlotCount = ItemAntiqueBag.SLOT_COUNT;

            if (index < bagSlotCount) {
                // Transfer from bag to player inventory
                if (!this.func_75135_a(slotStack, bagSlotCount, this.field_75151_b.size(), true)) {
                    return ItemStack.field_190927_a;
                }
            } else {
                // Transfer from player inventory to bag
                if (!this.func_75135_a(slotStack, 0, bagSlotCount, false)) {
                    return ItemStack.field_190927_a;
                }
            }

            if (slotStack.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }

            if (slotStack.func_190916_E() == resultStack.func_190916_E()) {
                return ItemStack.field_190927_a;
            }

            slot.func_190901_a(playerIn, slotStack);
        }

        return resultStack;
    }

    @Override
    public void func_75134_a(EntityPlayer playerIn) {
        super.func_75134_a(playerIn);
        bagInventory.func_174886_c(playerIn);
    }

    /**
     * Custom slot that only accepts allowed items.
     * Flowers (artificial_flower) are only allowed in the first 2 slots (index 0 and 1).
     * Matches high-version logic: (isBook(stack) || (isFlower && index < 2))
     */
    public static class SlotAntiqueBag extends Slot {
        private final int bagSlotIndex;

        public SlotAntiqueBag(IInventory inventoryIn, int index, int xPosition, int yPosition) {
            super(inventoryIn, index, xPosition, yPosition);
            this.bagSlotIndex = index;
        }

        @Override
        public boolean func_75214_a(ItemStack stack) {
            boolean isFlowerInFirstTwo = ItemAntiqueBag.isFlower(stack) && bagSlotIndex < 2;
            return ItemAntiqueBag.isBook(stack) || isFlowerInFirstTwo;
        }

        @Override
        public int func_75219_a() {
            return 1;
        }
    }
}
