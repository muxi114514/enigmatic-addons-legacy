package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.common.util.Constants;
import net.mx.eaddons.EAddonsMod;
import keletu.enigmaticlegacy.EnigmaticLegacy;

import java.util.Arrays;
import java.util.List;

public class ItemAntiqueBag extends Item {
    public static final ItemAntiqueBag INSTANCE = new ItemAntiqueBag();
    public static final int SLOT_COUNT = 12;
    private static final String NBT_TAG = "JMHeavenAntiqueBag";

    /**
     * List of allowed item registry names that can be placed in the bag.
     */
    public static final List<ResourceLocation> ALLOWED_ITEMS = Arrays.asList(
            new ResourceLocation("enigmaticlegacy", "the_acknowledgment"),
            new ResourceLocation("enigmaticlegacy", "the_twist"),
            new ResourceLocation("enigmaticlegacy", "the_infinitum"),
            new ResourceLocation("enigmaticlegacy", "half_heart_mask"));

    public ItemAntiqueBag() {
        func_77656_e(0);
        field_77777_bU = 1;
        func_77655_b("antique_bag");
        setRegistryName("antique_bag");
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }

    @Override
    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        if (!world.field_72995_K) {
            player.openGui(EAddonsMod.instance, AntiqueBagGuiHandler.GUI_ID, world,
                    (int) player.field_70165_t, (int) player.field_70163_u, (int) player.field_70161_v);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.func_184586_b(hand));
    }

    /**
     * Check if an item is a "book" (legacy relic) that goes in any bag slot.
     */
    public static boolean isBook(ItemStack stack) {
        if (stack.func_190926_b())
            return false;
        ResourceLocation regName = stack.func_77973_b().getRegistryName();
        return regName != null && ALLOWED_ITEMS.contains(regName);
    }

    /**
     * Check if an item is allowed to be placed in the bag (book or flower).
     */
    public static boolean isAllowedItem(ItemStack stack) {
        return isBook(stack) || isFlower(stack);
    }

    /**
     * Read the bag inventory from the player's persistent NBT data.
     */
    public static NonNullList<ItemStack> getInventory(EntityPlayer player) {
        NonNullList<ItemStack> inventory = NonNullList.func_191197_a(SLOT_COUNT, ItemStack.field_190927_a);
        NBTTagCompound persistent = getPersistentData(player);

        if (persistent.func_74764_b(NBT_TAG)) {
            NBTTagList tagList = persistent.func_150295_c(NBT_TAG, Constants.NBT.TAG_COMPOUND);
            for (int i = 0; i < tagList.func_74745_c(); i++) {
                NBTTagCompound tag = tagList.func_150305_b(i);
                int slot = tag.func_74762_e("Slot");
                if (slot >= 0 && slot < SLOT_COUNT) {
                    inventory.set(slot, new ItemStack(tag.func_74775_l("Item")));
                }
            }
        }
        return inventory;
    }

    /**
     * Write the bag inventory to the player's persistent NBT data.
     */
    public static void setInventory(EntityPlayer player, NonNullList<ItemStack> inventory) {
        NBTTagCompound persistent = getPersistentData(player);
        NBTTagList tagList = new NBTTagList();
        for (int i = 0; i < inventory.size(); i++) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.func_74768_a("Slot", i);
            tag.func_74782_a("Item", inventory.get(i).func_77955_b(new NBTTagCompound()));
            tagList.func_74742_a(tag);
        }
        persistent.func_74782_a(NBT_TAG, tagList);
    }

    private static NBTTagCompound getPersistentData(EntityPlayer player) {
        NBTTagCompound data = player.getEntityData();
        if (!data.func_74764_b(EntityPlayer.PERSISTED_NBT_TAG)) {
            data.func_74782_a(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        }
        return data.func_74775_l(EntityPlayer.PERSISTED_NBT_TAG);
    }

    /**
     * Check if the player has the bag in their inventory or ender chest.
     */
    public static boolean hasBag(EntityPlayer player) {
        // Check main inventory
        for (ItemStack stack : player.field_71071_by.field_70462_a) {
            if (stack.func_77973_b() instanceof ItemAntiqueBag)
                return true;
        }
        for (ItemStack stack : player.field_71071_by.field_184439_c) {
            if (stack.func_77973_b() instanceof ItemAntiqueBag)
                return true;
        }

        // Check ender chest
        InventoryEnderChest enderChest = player.func_71005_bN();
        for (int i = 0; i < enderChest.func_70302_i_(); i++) {
            ItemStack stack = enderChest.func_70301_a(i);
            if (stack.func_77973_b() instanceof ItemAntiqueBag)
                return true;
        }

        return false;
    }

    /**
     * Check if a specific item (by registry name) exists in the bag inventory.
     * Returns true if at least one copy is found.
     */
    public static boolean hasItemInBag(EntityPlayer player, ResourceLocation itemId) {
        if (!hasBag(player))
            return false;
        NonNullList<ItemStack> inv = getInventory(player);
        for (ItemStack stack : inv) {
            if (!stack.func_190926_b()) {
                ResourceLocation regName = stack.func_77973_b().getRegistryName();
                if (regName != null && regName.equals(itemId))
                    return true;
            }
        }
        return false;
    }

    /**
     * Convenience method to directly check by item reference.
     */
    public static boolean hasItemInBag(EntityPlayer player, Item item) {
        ResourceLocation regName = item.getRegistryName();
        return regName != null && hasItemInBag(player, regName);
    }

    public static boolean isFlower(ItemStack stack) {
        return !stack.func_190926_b() && stack.func_77973_b() instanceof ItemArtificialFlower;
    }

    /**
     * Ticks flowers stored in the first 2 bag slots, applying their effects.
     */
    public static void tickFlowersInBag(EntityPlayer player) {
        if (!hasBag(player))
            return;
        NonNullList<ItemStack> inv = getInventory(player);
        boolean changed = false;
        for (int i = 0; i < 2 && i < inv.size(); i++) {
            ItemStack stack = inv.get(i);
            if (isFlower(stack)) {
                stack.func_77973_b().func_77663_a(stack, player.field_70170_p, player, i, false);
                NBTTagCompound tag = stack.func_77978_p();
                if (tag == null) {
                    tag = new NBTTagCompound();
                    stack.func_77982_d(tag);
                }
                tag.func_74757_a("FlowerEnable", false);
                tag.func_74768_a("FlowerBagEnable", i);
                changed = true;
            }
        }
        if (changed) {
            setInventory(player, inv);
        }
    }
}
