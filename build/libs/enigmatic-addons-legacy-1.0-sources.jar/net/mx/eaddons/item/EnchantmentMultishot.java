package net.mx.eaddons.item;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;

import net.minecraft.enchantment.Enchantment.Rarity;

public class EnchantmentMultishot extends Enchantment {
    public static final EnchantmentMultishot INSTANCE = new EnchantmentMultishot();

    public EnchantmentMultishot() {
        super(Rarity.RARE, EnumEnchantmentType.BOW, new EntityEquipmentSlot[] { EntityEquipmentSlot.MAINHAND });
        func_77322_b("eaddons.multishot");
        setRegistryName("eaddons", "multishot");
    }

    @Override
    public int func_77325_b() {
        return 1;
    }

    @Override
    public int func_77321_a(int level) {
        return 20;
    }

    @Override
    public int func_77317_b(int level) {
        return 50;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemDragonBow;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemDragonBow;
    }
}
