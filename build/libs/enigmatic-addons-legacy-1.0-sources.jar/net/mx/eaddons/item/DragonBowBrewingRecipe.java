package net.mx.eaddons.item;

import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.world.World;
import net.minecraftforge.registries.IForgeRegistryEntry;

import java.util.ArrayList;
import java.util.List;

public class DragonBowBrewingRecipe extends IForgeRegistryEntry.Impl<IRecipe> implements IRecipe {

    public DragonBowBrewingRecipe() {
        setRegistryName("eaddons", "dragon_bow_brewing");
    }

    @Override
    public boolean func_77569_a(InventoryCrafting inv, World world) {
        ItemStack bow = ItemStack.field_190927_a;
        List<ItemStack> potions = new ArrayList<>();

        for (int i = 0; i < inv.func_70302_i_(); i++) {
            ItemStack stack = inv.func_70301_a(i);
            if (!stack.func_190926_b()) {
                if (stack.func_77973_b() instanceof ItemDragonBow) {
                    if (!bow.func_190926_b()) return false;
                    bow = stack.func_77946_l();
                } else if (stack.func_77973_b() instanceof ItemSplashPotion) {
                    potions.add(stack);
                } else {
                    return false;
                }
            }
        }

        return !bow.func_190926_b() && !potions.isEmpty()
                && potions.size() <= DragonBowConfig.maxPotionAmount;
    }

    @Override
    public ItemStack func_77572_b(InventoryCrafting inv) {
        ItemStack bow = ItemStack.field_190927_a;
        boolean hasWater = false;
        List<PotionEffect> effects = new ArrayList<>();

        for (int i = 0; i < inv.func_70302_i_(); i++) {
            ItemStack stack = inv.func_70301_a(i);
            if (!stack.func_190926_b()) {
                if (stack.func_77973_b() instanceof ItemDragonBow) {
                    if (!bow.func_190926_b()) return ItemStack.field_190927_a;
                    bow = stack.func_77946_l();
                } else if (stack.func_77973_b() instanceof ItemSplashPotion) {
                    PotionType potionType = PotionUtils.func_185191_c(stack);
                    if (potionType == PotionType.field_185176_a.func_82594_a(new net.minecraft.util.ResourceLocation("water"))) {
                        hasWater = true;
                    }
                    effects.addAll(PotionUtils.func_185189_a(stack));
                }
            }
        }

        if (bow.func_190926_b()) return ItemStack.field_190927_a;

        if (hasWater) {
            ItemDragonBow.resetEffect(bow);
            return bow;
        }

        for (PotionEffect effect : effects) {
            ItemDragonBow.addEffect(bow, effect);
        }

        return effects.isEmpty() ? ItemStack.field_190927_a : bow;
    }

    @Override
    public boolean func_194133_a(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public ItemStack func_77571_b() {
        return ItemStack.field_190927_a;
    }

    @Override
    public boolean func_192399_d() {
        return true;
    }
}
