package net.mx.eaddons.item;

import baubles.api.BaublesApi;
import baubles.api.cap.IBaublesItemHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.Optional;

/**
 * In Hardcore worlds, replace any Emblem of Adventurer (in inventory, off-hand, or Baubles) with Insignia of Despair.
 * Runs every server tick so it works as soon as the item is in the player's inventory.
 */
public class EmblemAdventurerEventHandler {

    @SubscribeEvent
    @Optional.Method(modid = "baubles")
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.field_70170_p.field_72995_K) return;
        EntityPlayer player = event.player;
        if (player.field_70170_p == null || !player.field_70170_p.func_72912_H().func_76093_s()) return;

        ItemStack insignia = new ItemStack(ItemInsigniaOfDespair.INSTANCE);

        // Main inventory (hotbar + main grid)
        for (int i = 0; i < player.field_71071_by.func_70302_i_(); i++) {
            ItemStack stack = player.field_71071_by.func_70301_a(i);
            if (!stack.func_190926_b() && stack.func_77973_b() == ItemEmblemOfAdventurer.INSTANCE) {
                player.field_71071_by.func_70299_a(i, insignia.func_77946_l());
            }
        }

        // Off-hand
        ItemStack off = player.func_184592_cb();
        if (!off.func_190926_b() && off.func_77973_b() == ItemEmblemOfAdventurer.INSTANCE) {
            player.func_184201_a(EntityEquipmentSlot.OFFHAND, insignia.func_77946_l());
        }

        // Baubles slots
        IBaublesItemHandler handler = BaublesApi.getBaublesHandler(player);
        if (handler != null) {
            for (int i = 0; i < handler.getSlots(); i++) {
                ItemStack inSlot = handler.getStackInSlot(i);
                if (!inSlot.func_190926_b() && inSlot.func_77973_b() == ItemEmblemOfAdventurer.INSTANCE) {
                    handler.setStackInSlot(i, insignia.func_77946_l());
                }
            }
        }
    }
}
