package net.mx.eaddons.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import net.mx.eaddons.EAddonsMod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EtheriumCoreEventHandler {

    private static final Map<UUID, Long> COOLDOWN_UNTIL = new HashMap<>();
    private static final Map<UUID, Integer> SHIELD_TICKS = new HashMap<>();
    /** Stored damage bonus for next attack (Etherium conversion). */
    private static final Map<UUID, Float> COUNTERATTACK_STORED = new HashMap<>();

    public static boolean isOnCooldown(EntityPlayer player) {
        if (player == null || player.field_70170_p == null) return true;
        Long until = COOLDOWN_UNTIL.get(player.func_110124_au());
        return until != null && player.field_70170_p.func_82737_E() < until;
    }

    public static int getCooldownRemainingTicks(EntityPlayer player) {
        if (player == null || player.field_70170_p == null) return 0;
        Long until = COOLDOWN_UNTIL.get(player.func_110124_au());
        if (until == null) return 0;
        long remaining = until - player.field_70170_p.func_82737_E();
        return remaining > 0 ? (int) remaining : 0;
    }

    public static void setCooldown(EntityPlayer player) {
        if (player == null) return;
        int ticks = EtheriumCoreConfig.cooldownTicks;
        if (ItemForgerGem.hasLostEngine(player)) {
            ticks = (int) (ticks * EtheriumCoreConfig.lostEngineCooldownFactor);
        }
        COOLDOWN_UNTIL.put(player.func_110124_au(), player.field_70170_p.func_82737_E() + ticks);
    }

    /** True if our active shield is up, or full Etherium set + health <= 60% with Core. */
    public static boolean hasShield(EntityPlayer player) {
        if (player == null || !ItemEtheriumCore.hasEtheriumCore(player)) return false;
        if (SHIELD_TICKS.getOrDefault(player.func_110124_au(), 0) > 0) return true;
        if (ItemEtheriumCore.hasFullEtheriumSet(player)) {
            float threshold = 0.4F * EtheriumCoreConfig.shieldThresholdMultiplier;
            return player.func_110143_aJ() / player.func_110138_aP() <= threshold;
        }
        return false;
    }

    public static int getShieldTicks(EntityPlayer player) {
        return player == null ? 0 : SHIELD_TICKS.getOrDefault(player.func_110124_au(), 0);
    }

    /** Called from EtheriumCoreTriggerMessage.Handler on server. */
    public static void onTrigger(EntityPlayerMP player) {
        if (player.field_70170_p.field_72995_K) return;
        if (!ItemEtheriumCore.hasEtheriumCore(player)) return;
        if (isOnCooldown(player)) return;
        setCooldown(player);
        SHIELD_TICKS.put(player.func_110124_au(), EtheriumCoreConfig.shieldDurationTicks);
        int cooldownTicks = getCooldownRemainingTicks(player);
        int shieldTicks = getShieldTicks(player);
        EAddonsMod.PACKET_HANDLER.sendTo(new EtheriumCoreSyncMessage(cooldownTicks, shieldTicks), player);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.field_70170_p.field_72995_K) return;
        EntityPlayer player = event.player;
        if (!ItemEtheriumCore.hasEtheriumCore(player)) return;
        UUID uuid = player.func_110124_au();
        Integer ticks = SHIELD_TICKS.get(uuid);
        if (ticks != null && ticks > 0) {
            int next = ticks - 1;
            if (next <= 0) SHIELD_TICKS.remove(uuid);
            else SHIELD_TICKS.put(uuid, next);
        }
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID uuid = event.player.func_110124_au();
        COOLDOWN_UNTIL.remove(uuid);
        SHIELD_TICKS.remove(uuid);
        COUNTERATTACK_STORED.remove(uuid);
    }

    @SubscribeEvent(priority = net.minecraftforge.fml.common.eventhandler.EventPriority.HIGH)
    public void onLivingAttack(LivingAttackEvent event) {
        if (event.getEntityLiving().field_70170_p.field_72995_K) return;
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        if (!ItemEtheriumCore.hasEtheriumCore(player)) return;

        String type = event.getSource().field_76373_n;
        boolean immune = DamageSource.field_191291_g.field_76373_n.equals(type)
                || DamageSource.field_76367_g.field_76373_n.equals(type)
                || "thorns".equals(type)
                || "explosion".equals(type)
                || "explosion.player".equals(type);
        if (immune) {
            event.setCanceled(true);
            return;
        }

        if (event.getSource().func_76364_f() instanceof IProjectile || event.getSource().func_76364_f() instanceof EntityArrow) {
            if (hasShield(player)) {
                event.setCanceled(true);
                player.field_70170_p.func_184133_a(null, player.func_180425_c(), SoundEvents.field_189107_dL, SoundCategory.PLAYERS, 1.0F, 0.9F + (float) (Math.random() * 0.1));
            }
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntityLiving().field_70170_p.field_72995_K) return;

        if (event.getEntityLiving() instanceof EntityPlayer) {
            EntityPlayer victim = (EntityPlayer) event.getEntityLiving();
            if (ItemEtheriumCore.hasEtheriumCore(victim)) {
                float add = event.getAmount() * EtheriumCoreConfig.damageConversion;
                float current = COUNTERATTACK_STORED.getOrDefault(victim.func_110124_au(), 0F);
                float capped = Math.min(EtheriumCoreConfig.damageConversionCap, current + add);
                COUNTERATTACK_STORED.put(victim.func_110124_au(), capped);
                if (hasShield(victim)) {
                    Entity source = event.getSource().func_76346_g();
                    if (source instanceof EntityLivingBase) {
                        EntityLivingBase attacker = (EntityLivingBase) source;
                        double dx = victim.field_70165_t - attacker.field_70165_t;
                        double dz = victim.field_70161_v - attacker.field_70161_v;
                        double len = Math.sqrt(dx * dx + dz * dz);
                        if (len > 0.001) {
                            float rx = (float) (dx / len);
                            float rz = (float) (dz / len);
                            attacker.func_70653_a(victim, 0.75F, rx, rz);
                        }
                        victim.field_70170_p.func_184133_a(null, victim.func_180425_c(), SoundEvents.field_187767_eL, SoundCategory.PLAYERS, 1.0F, 0.9F + (float) (Math.random() * 0.1));
                    }
                    event.setAmount(event.getAmount() * 0.5F);
                }
            }
        }

        Entity trueSource = event.getSource().func_76346_g();
        if (trueSource instanceof EntityPlayer) {
            EntityPlayer attacker = (EntityPlayer) trueSource;
            if (ItemEtheriumCore.hasEtheriumCore(attacker)) {
                Float stored = COUNTERATTACK_STORED.remove(attacker.func_110124_au());
                if (stored != null && stored > 0) {
                    event.setAmount(event.getAmount() + stored);
                }
            }
        }
    }
}
