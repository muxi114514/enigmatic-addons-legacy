package net.mx.eaddons.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.monster.AbstractIllager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class TotemOfMaliceEventHandler {

    /** Half-heart (1 HP): immediate survival so player does not die / lose inventory. */
    private static final float SURVIVAL_HEALTH = 1.0F;
    /** Ticks to wait before applying full heal after totem save. 20 = 1 second. */
    private static final int FULL_HEAL_DELAY_TICKS = 20;
    /** Extra HP granted on delayed heal (on top of max health). */
    private static final float DELAYED_HEAL_BONUS_HP = 1000.0F;
    /** Ticks to keep sending vanilla health packet so client bar wins over First Aid's tick overwrite. */
    private static final int VANILLA_HEALTH_SYNC_TICKS = 5;

    /** Player UUID -> world time when to apply full heal. */
    private static final Map<UUID, Long> pendingFullHeal = new HashMap<>();
    /** Player UUID -> target health to send. First Aid overwrites HEALTH each tick; we re-send so client bar matches. */
    private static final Map<UUID, Float> pendingVanillaHealthSyncHealth = new HashMap<>();
    /** Player UUID -> world time (long) until we stop sending. */
    private static final Map<UUID, Long> pendingVanillaHealthSyncUntil = new HashMap<>();

    private static boolean isIllager(Entity entity) {
        if (entity == null) return false;
        Set<net.minecraft.util.ResourceLocation> ids = TotemOfMaliceConfig.getIllagerEntityIds();
        if (!ids.isEmpty()) {
            net.minecraft.util.ResourceLocation key = net.minecraft.entity.EntityList.func_191301_a(entity);
            return key != null && ids.contains(key);
        }
        return entity instanceof AbstractIllager;
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntityLiving().field_70170_p.field_72995_K)
            return;

        Entity sourceEntity = event.getSource().func_76346_g();

        // Attacker has totem, target is illager: increase damage
        if (sourceEntity instanceof EntityPlayer) {
            EntityPlayer attacker = (EntityPlayer) sourceEntity;
            if (ItemTotemOfMalice.hasTotemOfMalice(attacker) && isIllager(event.getEntityLiving())) {
                float mult = 1.0F + TotemOfMaliceConfig.damageBonusPercent / 100.0F;
                event.setAmount(event.getAmount() * mult);
            }
        }

        // Victim has totem, source is illager: reduce damage
        if (event.getEntityLiving() instanceof EntityPlayer) {
            EntityPlayer victim = (EntityPlayer) event.getEntityLiving();
            if (ItemTotemOfMalice.hasTotemOfMalice(victim) && isIllager(sourceEntity)) {
                float mult = 1.0F - TotemOfMaliceConfig.damageReductionPercent / 100.0F;
                event.setAmount(event.getAmount() * mult);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntityLiving() instanceof EntityPlayer))
            return;
        if (event.getEntityLiving().field_70170_p.field_72995_K)
            return;

        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        ItemStack totemStack = ItemTotemOfMalice.getTotemStack(player);
        if (totemStack.func_190926_b() || ItemTotemOfMalice.getRemainingUses(totemStack) <= 0)
            return;

        event.setCanceled(true);

        player.func_70606_j(SURVIVAL_HEALTH);
        long deadline = player.field_70170_p.func_82737_E() + FULL_HEAL_DELAY_TICKS;
        pendingFullHeal.put(player.func_110124_au(), deadline);

        float maxHp = player.func_110138_aP();
        int curseCount = ItemTotemOfMalice.getCurseCount(totemStack);
        float curseMult = 1.0F + (TotemOfMaliceConfig.curseBonusPercent / 100.0F) * curseCount;
        float damage = maxHp * TotemOfMaliceConfig.deathBurstMultiplier * curseMult;

        double r = TotemOfMaliceConfig.aoeRadius;
        AxisAlignedBB box = player.func_174813_aQ().func_72314_b(r, r, r);
        List<EntityLivingBase> nearby = player.field_70170_p.func_72872_a(EntityLivingBase.class, box);
        DamageSource ds = DamageSource.func_76354_b(player, player);

        for (EntityLivingBase target : nearby) {
            if (target == player || !target.func_70089_S()) continue;
            target.func_70097_a(ds, damage);
        }

        ItemTotemOfMalice.consumeOneUse(totemStack);

        if (!player.field_70170_p.field_72995_K) {
            player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v,
                    SoundEvents.field_191263_gW, SoundCategory.PLAYERS, 1.0F, 1.0F);
            for (int i = 0; i < 20; i++) {
                player.field_70170_p.func_175688_a(EnumParticleTypes.ENCHANTMENT_TABLE,
                        player.field_70165_t, player.field_70163_u + 1.0, player.field_70161_v,
                        0.5, 0.5, 0.5, 0);
            }
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END)
            return;

        for (net.minecraft.entity.player.EntityPlayerMP p : FMLCommonHandler.instance().getMinecraftServerInstance().func_184103_al().func_181057_v()) {
            Long deadline = pendingFullHeal.get(p.func_110124_au());
            if (deadline != null && p.field_70170_p.func_82737_E() >= deadline) {
                pendingFullHeal.remove(p.func_110124_au());
                float targetHealth = p.func_110138_aP() + DELAYED_HEAL_BONUS_HP;
                p.func_70606_j(targetHealth);
                if (AntiqueBagCompatFirstAid.isAvailable()) {
                    AntiqueBagCompatFirstAid.fullHealFirstAid(p);
                }
                // First Aid's tick overwrites HEALTH from body parts and syncs to client; send vanilla packet with target value for several ticks so client bar matches.
                long sendUntil = p.field_70170_p.func_82737_E() + VANILLA_HEALTH_SYNC_TICKS;
                pendingVanillaHealthSyncHealth.put(p.func_110124_au(), targetHealth);
                pendingVanillaHealthSyncUntil.put(p.func_110124_au(), sendUntil);
            }
        }

        Iterator<UUID> it = pendingVanillaHealthSyncUntil.keySet().iterator();
        while (it.hasNext()) {
            UUID uuid = it.next();
            EntityPlayerMP q = FMLCommonHandler.instance().getMinecraftServerInstance().func_184103_al().func_177451_a(uuid);
            if (q == null || q.field_71135_a == null) {
                it.remove();
                pendingVanillaHealthSyncHealth.remove(uuid);
                continue;
            }
            Long sendUntil = pendingVanillaHealthSyncUntil.get(uuid);
            if (sendUntil == null || q.field_70170_p.func_82737_E() >= sendUntil) {
                it.remove();
                pendingVanillaHealthSyncHealth.remove(uuid);
                continue;
            }
            Float health = pendingVanillaHealthSyncHealth.get(uuid);
            if (health != null) {
                q.field_71135_a.func_147359_a(new SPacketUpdateHealth(
                        health,
                        q.func_71024_bL().func_75116_a(),
                        q.func_71024_bL().func_75115_e()));
            }
        }
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID uuid = event.player.func_110124_au();
        pendingFullHeal.remove(uuid);
        pendingVanillaHealthSyncHealth.remove(uuid);
        pendingVanillaHealthSyncUntil.remove(uuid);
    }
}
