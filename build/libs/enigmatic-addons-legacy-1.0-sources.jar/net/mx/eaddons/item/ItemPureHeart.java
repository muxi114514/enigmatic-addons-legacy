package net.mx.eaddons.item;

import keletu.enigmaticlegacy.EnigmaticLegacy;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemPureHeart extends Item {
    public static final ItemPureHeart INSTANCE = new ItemPureHeart();

    public ItemPureHeart() {
        func_77656_e(0);
        field_77777_bU = 1;
        func_77655_b("pure_heart");
        setRegistryName("pure_heart");
        func_77637_a(EnigmaticLegacy.tabEnigmaticLegacy);
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC;
    }
}
