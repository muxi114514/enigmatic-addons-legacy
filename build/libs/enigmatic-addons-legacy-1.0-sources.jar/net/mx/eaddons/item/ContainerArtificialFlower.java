package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.SoundCategory;

import java.util.UUID;

public class ContainerArtificialFlower extends Container {
    public final EntityPlayer player;
    private final IInventory enchantSlot;
    private final IInventory ringSlot;
    public int costMode;

    public ContainerArtificialFlower(EntityPlayer player) {
        this.player = player;
        this.costMode = 0;
        this.enchantSlot = new InventoryBasic("Enchant", false, 2);
        this.ringSlot = new InventoryBasic("Ring", false, 1);

        ItemStack flowerStack = ItemArtificialFlower.Helper.getFlowerStack(player, true);
        NBTTagCompound flowerTag = flowerStack.func_77978_p();
        if (flowerTag != null && flowerTag.func_74764_b("MagicRing")) {
            NBTTagCompound ringNBT = flowerTag.func_74775_l("MagicRing");
            ringSlot.func_70299_a(0, new ItemStack(ringNBT));
        }

        this.func_75146_a(new SlotExact(this.enchantSlot, Items.field_151100_aR, 4, 0, 17, 31));
        this.func_75146_a(new SlotExact(this.enchantSlot, Items.field_151128_bU, -1, 1, 106, 31));
        this.func_75146_a(new SlotRing(this.ringSlot, 0, 80, 27));

        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 9; j++) {
                this.func_75146_a(new Slot(player.field_71071_by, j + k * 9 + 9, 8 + j * 18, 84 + k * 18));
            }
        }

        for (int k = 0; k < 9; k++) {
            if (k == player.field_71071_by.field_70461_c) {
                this.func_75146_a(new Slot(player.field_71071_by, k, 8 + k * 18, 142) {
                    @Override
                    public boolean func_82869_a(EntityPlayer playerIn) {
                        return false;
                    }

                    @Override
                    public boolean func_75214_a(ItemStack stack) {
                        return false;
                    }

                    @Override
                    public int func_75219_a() {
                        return 0;
                    }
                });
            } else {
                this.func_75146_a(new Slot(player.field_71071_by, k, 8 + k * 18, 142));
            }
        }
    }

    @Override
    public boolean func_75140_a(EntityPlayer player, int id) {
        if (id >= 0 && id < 3) {
            ItemStack lapis = this.enchantSlot.func_70301_a(0);
            if (lapis.func_190926_b() && !player.field_71075_bZ.field_75098_d) return false;
            int cost = this.costMode == 0 ? 2 : this.costMode == 1 ? 4 : 8;
            if (lapis.func_190916_E() < cost && !player.field_71075_bZ.field_75098_d) return false;

            if (!player.field_70170_p.field_72995_K) {
                ItemArtificialFlower.Helper.randomAttribute(player,
                        ItemArtificialFlower.Helper.getFlowerStack(player, false),
                        id + 1, this.costMode, !this.ringSlot.func_70301_a(0).func_190926_b());
                player.field_70170_p.func_184133_a(null, player.func_180425_c(),
                        SoundEvents.field_190021_aL, SoundCategory.BLOCKS,
                        1.0F, player.field_70170_p.field_73012_v.nextFloat() * 0.1F + 0.9F);
                if (!player.field_71075_bZ.field_75098_d) {
                    lapis.func_190918_g(cost);
                    if (lapis.func_190926_b()) this.enchantSlot.func_70299_a(0, ItemStack.field_190927_a);
                }
            }
            return true;
        } else if (id == 3) {
            this.costMode = this.costMode == 2 ? 0 : this.costMode + 1;
            return true;
        } else if (id == 4 || id == 5) {
            ItemStack quartz = this.enchantSlot.func_70301_a(1);
            if (quartz.func_190926_b() && !player.field_71075_bZ.field_75098_d) return false;
            if (quartz.func_190916_E() < 4 && !player.field_71075_bZ.field_75098_d) return false;

            if (!player.field_70170_p.field_72995_K) {
                ItemArtificialFlower.Helper.randomEffect(player,
                        ItemArtificialFlower.Helper.getFlowerStack(player, false),
                        id - 4);
                player.field_70170_p.func_184133_a(null, player.func_180425_c(),
                        SoundEvents.field_190021_aL, SoundCategory.BLOCKS,
                        1.0F, player.field_70170_p.field_73012_v.nextFloat() * 0.1F + 0.9F);
                if (!player.field_71075_bZ.field_75098_d) {
                    quartz.func_190918_g(4);
                    if (quartz.func_190926_b()) this.enchantSlot.func_70299_a(1, ItemStack.field_190927_a);
                }
            }
            return true;
        }
        return false;
    }

    public boolean valid(int index) {
        if (index > 1) return false;
        boolean[] flag = {
                this.enchantSlot.func_70301_a(0).func_190916_E() >= (this.costMode == 0 ? 2 : this.costMode == 1 ? 4 : 8),
                this.enchantSlot.func_70301_a(1).func_190916_E() >= 4
        };
        return !this.enchantSlot.func_70301_a(index).func_190926_b() && flag[index];
    }

    public boolean hasRing() {
        return !this.ringSlot.func_70301_a(0).func_190926_b();
    }

    @Override
    public ItemStack func_82846_b(EntityPlayer playerIn, int index) {
        ItemStack result = ItemStack.field_190927_a;
        int slotsCount = 3;
        Slot slot = this.field_75151_b.get(index);
        if (slot != null && slot.func_75216_d()) {
            ItemStack slotItem = slot.func_75211_c();
            result = slotItem.func_77946_l();
            if (index < slotsCount) {
                if (!this.func_75135_a(slotItem, slotsCount, this.field_75151_b.size(), true)) {
                    return ItemStack.field_190927_a;
                }
            } else if (!this.func_75135_a(slotItem, 0, slotsCount, false)) {
                return ItemStack.field_190927_a;
            }

            if (slotItem.func_190926_b()) slot.func_75215_d(ItemStack.field_190927_a);
            else slot.func_75218_e();
            if (slotItem.func_190916_E() == result.func_190916_E()) return ItemStack.field_190927_a;
            slot.func_190901_a(playerIn, slotItem);
        }
        return result;
    }

    @Override
    public void func_75134_a(EntityPlayer player) {
        super.func_75134_a(player);
        if (player instanceof EntityPlayerMP) {
            for (int i = 0; i < 2; i++) {
                ItemStack stack = this.enchantSlot.func_70301_a(i);
                if (!stack.func_190926_b()) {
                    if (player.func_70089_S() && !((EntityPlayerMP) player).func_193105_t()) {
                        player.field_71071_by.func_191975_a(player.field_70170_p, stack);
                    } else {
                        player.func_71019_a(stack, false);
                    }
                    this.enchantSlot.func_70299_a(i, ItemStack.field_190927_a);
                }
            }

            ItemStack flowerStack = ItemArtificialFlower.Helper.getFlowerStack(player, false);
            if (!flowerStack.func_190926_b()) {
                NBTTagCompound tag = flowerStack.func_77978_p();
                if (tag == null) {
                    tag = new NBTTagCompound();
                    flowerStack.func_77982_d(tag);
                }
                UUID uuid = UUID.randomUUID();
                ItemArtificialFlower.Helper.setPlayerEnableUUID(player, uuid);
                tag.func_186854_a("FlowerUUID", uuid);
                tag.func_74757_a("FlowerEnable", true);

                ItemStack ring = this.ringSlot.func_70301_a(0);
                if (!ring.func_190926_b()) {
                    NBTTagCompound ringTag = ring.func_77955_b(new NBTTagCompound());
                    tag.func_74782_a("MagicRing", ringTag);
                } else {
                    tag.func_82580_o("MagicRing");
                }
            }
        }
    }

    @Override
    public boolean func_75145_c(EntityPlayer playerIn) {
        return true;
    }

    /**
     * Slot that only accepts a specific item. For lapis lazuli (dye meta=4) or quartz.
     */
    public static class SlotExact extends Slot {
        private final Item acceptedItem;
        private final int acceptedMeta;

        public SlotExact(IInventory inventoryIn, Item item, int meta, int index, int x, int y) {
            super(inventoryIn, index, x, y);
            this.acceptedItem = item;
            this.acceptedMeta = meta;
        }

        @Override
        public boolean func_75214_a(ItemStack stack) {
            if (acceptedMeta >= 0) {
                return stack.func_77973_b() == acceptedItem && stack.func_77960_j() == acceptedMeta;
            }
            return stack.func_77973_b() == acceptedItem;
        }
    }

    public static class SlotRing extends Slot {
        public SlotRing(IInventory inventoryIn, int index, int x, int y) {
            super(inventoryIn, index, x, y);
        }

        @Override
        public boolean func_75214_a(ItemStack stack) {
            return stack.func_77973_b() instanceof ItemQuartzRing;
        }

        @Override
        public int func_75219_a() {
            return 1;
        }
    }
}
