package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.mx.eaddons.EAddonsMod;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EarthPromiseEventHandler {
    /** Cooldown end time (world total world time) per player UUID. */
    private static final Map<UUID, Long> COOLDOWN_UNTIL = new HashMap<>();

    public static boolean isOnCooldown(EntityPlayer player) {
        if (player == null || player.field_70170_p == null) return true;
        Long until = COOLDOWN_UNTIL.get(player.func_110124_au());
        return until != null && player.field_70170_p.func_82737_E() < until;
    }

    public static void setCooldown(EntityPlayer player) {
        if (player == null) return;
        int ticks = EarthPromiseConfig.cooldownTicks;
        if (ItemForgerGem.hasLostEngine(player)) {
            ticks = (int) (ticks * EarthPromiseConfig.lostEngineCooldownFactor);
        }
        COOLDOWN_UNTIL.put(player.func_110124_au(), player.field_70170_p.func_82737_E() + ticks);
    }

    /** Used when sending cooldown to client so tooltip shows correct remaining time. */
    public static int getEffectiveCooldownTicks(EntityPlayer player) {
        int ticks = EarthPromiseConfig.cooldownTicks;
        if (ItemForgerGem.hasLostEngine(player)) {
            ticks = (int) (ticks * EarthPromiseConfig.lostEngineCooldownFactor);
        }
        return ticks;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof EntityPlayer)) return;
        EntityPlayer player = (EntityPlayer) event.getEntity();
        if (!ItemEarthPromise.hasEarthPromise(player)) return;

        float damage = event.getAmount();
        float triggerThreshold = player.func_110143_aJ() * (EarthPromiseConfig.abilityTriggerPercent / 100.0F);

        if (ItemForgerGem.hasCursedRing(player)) {
            damage = damage * (1.0F - EarthPromiseConfig.getFirstCurseResistanceMultiplier());
        }

        if (isOnCooldown(player)) {
            event.setAmount(damage);
            return;
        }

        if (player.func_70089_S() && !event.getSource().func_76363_c() && damage >= triggerThreshold) {
            setCooldown(player);
            if (!player.field_70170_p.field_72995_K && player instanceof EntityPlayerMP) {
                EAddonsMod.PACKET_HANDLER.sendTo(new EarthPromiseCooldownMessage(getEffectiveCooldownTicks(player)), (EntityPlayerMP) player);
            }
            if (!player.field_70170_p.field_72995_K) {
                player.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, player.field_70165_t, player.field_70163_u, player.field_70161_v, 1, 0, 0, 0);
                for (int i = 0; i < 36; i++) {
                    player.field_70170_p.func_175688_a(EnumParticleTypes.END_ROD,
                            player.field_70165_t, player.field_70163_u + 0.5, player.field_70161_v,
                            0.1, 0.1, 0.1, 0);
                }
                player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v,
                        SoundEvents.field_193777_bb, SoundCategory.PLAYERS, 5.0F, 1.5F);
            }
            event.setCanceled(true);
        } else {
            event.setAmount(damage);
        }
    }

    @SubscribeEvent
    public void onBreakSpeed(net.minecraftforge.event.entity.player.PlayerEvent.BreakSpeed event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player == null || !ItemEarthPromise.hasEarthPromise(player)) return;
        float bonus = EarthPromiseConfig.getBreakSpeedMultiplier();
        event.setNewSpeed(event.getNewSpeed() * (1.0F + bonus));
    }

    @SubscribeEvent
    public void onHarvestDrops(BlockEvent.HarvestDropsEvent event) {
        EntityPlayer harvester = event.getHarvester();
        if (harvester == null || !ItemEarthPromise.hasEarthPromise(harvester)) return;
        int bonus = EarthPromiseConfig.fortuneBonus;
        if (bonus <= 0 || event.getDrops().isEmpty()) return;
        java.util.List<net.minecraft.item.ItemStack> drops = event.getDrops();
        java.util.List<net.minecraft.item.ItemStack> toAdd = new java.util.ArrayList<>();
        for (net.minecraft.item.ItemStack original : drops) {
            if (original.func_190926_b()) continue;
            for (int i = 0; i < bonus; i++) {
                if (harvester.field_70170_p.field_73012_v.nextFloat() < 0.5F) {
                    net.minecraft.item.ItemStack extra = original.func_77946_l();
                    extra.func_190920_e(1);
                    toAdd.add(extra);
                }
            }
        }
        drops.addAll(toAdd);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.field_70170_p.field_72995_K) return;
        Long until = COOLDOWN_UNTIL.get(event.player.func_110124_au());
        if (until != null && event.player.field_70170_p.func_82737_E() >= until) {
            COOLDOWN_UNTIL.remove(event.player.func_110124_au());
        }
    }
}
