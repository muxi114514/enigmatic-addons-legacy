package net.mx.eaddons.item;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ForgerGemClientHelper {

    public static EntityPlayer findPlayerForAnvil(ItemStack eventLeft) {
        EntityPlayer player = Minecraft.func_71410_x().field_71439_g;
        if (player != null && player.field_71070_bA instanceof ContainerRepair) {
            ContainerRepair anvil = (ContainerRepair) player.field_71070_bA;
            if (anvil.func_75139_a(0).func_75211_c() == eventLeft) {
                return player;
            }
        }
        return null;
    }
}
