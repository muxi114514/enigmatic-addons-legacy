package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.play.server.SPacketWindowProperty;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.entity.player.AnvilRepairEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;

import java.util.Map;
import java.util.WeakHashMap;

public class ForgerGemEventHandler {

    private final Map<EntityPlayer, Integer> lastSetCost = new WeakHashMap<>();

    @SubscribeEvent
    public void onAnvilUpdate(AnvilUpdateEvent event) {
        EntityPlayer player = findAnvilPlayer(event);
        if (player == null) return;
        if (!ItemForgerGem.hasForgerGem(player)) return;
        if (!ItemForgerGem.hasRingEquipped(player)) return;

        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();

        if (!qualifiesForUnbreakable(player, left, right)) return;

        ItemStack result = left.func_77946_l();
        NBTTagCompound existingTag = result.func_77978_p();
        NBTTagCompound tag = existingTag != null ? existingTag.func_74737_b() : new NBTTagCompound();
        tag.func_74757_a("Unbreakable", true);
        result.func_77982_d(tag);
        result.func_82841_c(result.func_82838_A() + 8);

        String name = event.getName();
        if (name != null && !name.isEmpty()) {
            result.func_151001_c(name);
        }

        event.setOutput(result);
        event.setCost(30);
    }

    @SubscribeEvent
    public void onAnvilRepair(AnvilRepairEvent event) {
        EntityPlayer player = event.getEntityPlayer();
        if (player != null && !player.field_70170_p.field_72995_K && ItemForgerGem.hasForgerGem(player)) {
            event.setBreakChance(0F);
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.field_70170_p.field_72995_K) return;
        EntityPlayer player = event.player;

        if (!ItemForgerGem.hasForgerGem(player)) {
            lastSetCost.remove(player);
            return;
        }

        if (!(player.field_71070_bA instanceof ContainerRepair)) {
            lastSetCost.remove(player);
            return;
        }

        ContainerRepair anvil = (ContainerRepair) player.field_71070_bA;
        int currentCost = anvil.field_82854_e;

        if (currentCost <= 0) {
            lastSetCost.remove(player);
            return;
        }

        ItemStack output = anvil.func_75139_a(2).func_75211_c();
        NBTTagCompound outputTag = output.func_77978_p();
        if (!output.func_190926_b() && outputTag != null && outputTag.func_74767_n("Unbreakable")) {
            lastSetCost.remove(player);
            return;
        }

        Integer lastSet = lastSetCost.get(player);
        if (lastSet == null || currentCost != lastSet) {
            int halved = (currentCost + 1) / 2;
            anvil.field_82854_e = halved;
            lastSetCost.put(player, halved);

            if (player instanceof EntityPlayerMP) {
                ((EntityPlayerMP) player).field_71135_a.func_147359_a(
                        new SPacketWindowProperty(anvil.field_75152_c, 0, halved)
                );
            }
        }
    }

    /**
     * Finds the player whose open anvil container holds the same left input stack (by reference)
     * as the event. Works on both server (via player list) and client (via ForgerGemClientHelper).
     */
    private EntityPlayer findAnvilPlayer(AnvilUpdateEvent event) {
        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server != null) {
            ItemStack eventLeft = event.getLeft();
            for (EntityPlayerMP player : server.func_184103_al().func_181057_v()) {
                if (player.field_71070_bA instanceof ContainerRepair) {
                    ContainerRepair anvil = (ContainerRepair) player.field_71070_bA;
                    if (anvil.func_75139_a(0).func_75211_c() == eventLeft) {
                        return player;
                    }
                }
            }
            return null;
        }

        if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
            return ForgerGemClientHelper.findPlayerForAnvil(event.getLeft());
        }
        return null;
    }

    private boolean qualifiesForUnbreakable(EntityPlayer player, ItemStack left, ItemStack right) {
        if (left.func_190926_b() || right.func_190926_b()) return false;
        if (left.func_77973_b() != right.func_77973_b()) return false;
        if (!left.func_77984_f()) return false;
        if (left.func_77952_i() != 0 || right.func_77952_i() != 0) return false;
        if (left.func_77948_v() || right.func_77948_v()) return false;

        ResourceLocation itemId = ForgeRegistries.ITEMS.getKey(left.func_77973_b());
        if (itemId != null && ForgerGemConfig.isBlacklisted(itemId)) return false;

        if (ForgerGemConfig.strictUnbreakableForge && !player.field_71075_bZ.field_75098_d) {
            Item item = left.func_77973_b();
            if (!(item instanceof ItemTool || item instanceof ItemSword || item instanceof ItemArmor)) return false;
        }

        return true;
    }
}
