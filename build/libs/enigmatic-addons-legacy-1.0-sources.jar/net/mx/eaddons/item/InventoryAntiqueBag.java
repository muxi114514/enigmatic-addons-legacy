package net.mx.eaddons.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentTranslation;

/**
 * An IInventory wrapper that reads/writes directly from/to the player's
 * persistent NBT data for the Antique Bag.
 */
public class InventoryAntiqueBag implements IInventory {
    private final EntityPlayer player;
    private NonNullList<ItemStack> inventory;

    public InventoryAntiqueBag(EntityPlayer player) {
        this.player = player;
        this.inventory = ItemAntiqueBag.getInventory(player);
    }

    @Override
    public int func_70302_i_() {
        return ItemAntiqueBag.SLOT_COUNT;
    }

    @Override
    public boolean func_191420_l() {
        for (ItemStack stack : inventory) {
            if (!stack.func_190926_b())
                return false;
        }
        return true;
    }

    @Override
    public ItemStack func_70301_a(int index) {
        if (index < 0 || index >= func_70302_i_())
            return ItemStack.field_190927_a;
        return inventory.get(index);
    }

    @Override
    public ItemStack func_70298_a(int index, int count) {
        ItemStack stack = func_70301_a(index);
        if (!stack.func_190926_b()) {
            ItemStack result;
            if (stack.func_190916_E() <= count) {
                result = stack;
                inventory.set(index, ItemStack.field_190927_a);
            } else {
                result = stack.func_77979_a(count);
                if (stack.func_190916_E() == 0) {
                    inventory.set(index, ItemStack.field_190927_a);
                }
            }
            func_70296_d();
            return result;
        }
        return ItemStack.field_190927_a;
    }

    @Override
    public ItemStack func_70304_b(int index) {
        ItemStack stack = func_70301_a(index);
        if (!stack.func_190926_b()) {
            inventory.set(index, ItemStack.field_190927_a);
            func_70296_d();
        }
        return stack;
    }

    @Override
    public void func_70299_a(int index, ItemStack stack) {
        if (index >= 0 && index < func_70302_i_()) {
            inventory.set(index, stack);
            func_70296_d();
        }
    }

    @Override
    public int func_70297_j_() {
        return 1;
    }

    @Override
    public void func_70296_d() {
        ItemAntiqueBag.setInventory(player, inventory);
    }

    @Override
    public boolean func_70300_a(EntityPlayer player) {
        return true;
    }

    @Override
    public void func_174889_b(EntityPlayer player) {
        this.inventory = ItemAntiqueBag.getInventory(player);
    }

    @Override
    public void func_174886_c(EntityPlayer player) {
        func_70296_d();
    }

    @Override
    public boolean func_94041_b(int index, ItemStack stack) {
        if (ItemAntiqueBag.isFlower(stack)) {
            return index < 2;
        }
        return ItemAntiqueBag.isBook(stack);
    }

    @Override
    public int func_174887_a_(int id) {
        return 0;
    }

    @Override
    public void func_174885_b(int id, int value) {
    }

    @Override
    public int func_174890_g() {
        return 0;
    }

    @Override
    public void func_174888_l() {
        for (int i = 0; i < func_70302_i_(); i++) {
            inventory.set(i, ItemStack.field_190927_a);
        }
        func_70296_d();
    }

    @Override
    public String func_70005_c_() {
        return "container.eaddons.antique_bag";
    }

    @Override
    public boolean func_145818_k_() {
        return false;
    }

    @Override
    public ITextComponent func_145748_c_() {
        return new TextComponentTranslation(func_70005_c_());
    }
}
