package net.mx.eaddons.potion;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.mx.eaddons.item.DragonBowConfig;

import javax.annotation.Nullable;
import java.util.List;

public class PotionDragonBreath extends Potion {
    public static final PotionDragonBreath INSTANCE = new PotionDragonBreath();

    public PotionDragonBreath() {
        super(false, 0xdf61ff);
        setRegistryName("eaddons", "dragon_breath");
        func_76390_b("effect.eaddons.dragon_breath");
        func_111184_a(
                SharedMonsterAttributes.field_111263_d,
                "744bf4f9-0647-49a9-9f6c-be42d42faeee",
                -0.125D,
                2
        );
    }

    @Override
    public boolean func_76403_b() {
        return true;
    }

    @Override
    public boolean func_76397_a(int duration, int amplifier) {
        return true;
    }

    @Override
    public void func_180793_a(@Nullable Entity source, @Nullable Entity indirectSource,
                             EntityLivingBase target, int amplifier, double health) {
        float damage = (int) (health * (double) (4 << amplifier) + 0.5);

        if (indirectSource == target) {
            damage = damage * DragonBowConfig.getOwnerResistanceMultiplier();
            if (damage <= 0) return;
        }

        if (source == null) {
            target.func_70097_a(DamageSource.field_188407_q, damage);
        } else {
            target.func_70097_a(DamageSource.func_76354_b(source, indirectSource), damage);
        }

        target.field_70159_w = 0;
        target.field_70181_x = 0;
        target.field_70179_y = 0;
        target.field_70133_I = true;

        AxisAlignedBB searchBox = target.func_174813_aQ().func_72314_b(4.0, 2.0, 4.0);
        List<EntityAreaEffectCloud> effectClouds = target.field_70170_p.func_72872_a(
                EntityAreaEffectCloud.class, searchBox);
        if (!effectClouds.isEmpty()) {
            for (EntityAreaEffectCloud cloud : effectClouds) {
                if (cloud.func_70068_e(target) < cloud.func_184490_j() * cloud.func_184490_j()
                        && target != cloud.func_184494_w()) {
                    Vec3d targetPos = target.func_174791_d();
                    Vec3d cloudPos = cloud.func_174791_d();
                    Vec3d movement = new Vec3d(target.field_70159_w, target.field_70181_x, target.field_70179_y).func_186678_a(0.5D);
                    Vec3d newPos = cloudPos.func_178787_e(targetPos.func_178788_d(cloudPos).func_186678_a(0.5D));
                    cloud.func_70107_b(newPos.field_72450_a + movement.field_72450_a, newPos.field_72448_b + movement.field_72448_b, newPos.field_72449_c + movement.field_72449_c);
                    break;
                }
            }
        }
    }

    @Override
    public boolean shouldRenderInvText(PotionEffect effect) {
        return true;
    }

    @Override
    public boolean shouldRenderHUD(PotionEffect effect) {
        return true;
    }
}
